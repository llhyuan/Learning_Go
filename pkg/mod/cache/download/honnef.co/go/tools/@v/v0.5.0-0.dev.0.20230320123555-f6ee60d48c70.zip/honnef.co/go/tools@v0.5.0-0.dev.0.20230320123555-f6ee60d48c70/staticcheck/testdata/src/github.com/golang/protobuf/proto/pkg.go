// Package proto exists.
//
// Deprecated: Alas, it is deprecated.
package proto
