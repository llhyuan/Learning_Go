package foo

const X = 0
