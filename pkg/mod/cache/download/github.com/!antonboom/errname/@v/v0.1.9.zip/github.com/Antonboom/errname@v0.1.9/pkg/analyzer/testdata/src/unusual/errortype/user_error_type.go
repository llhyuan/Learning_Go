package errortype

type error string

var EndOfFileError = error("I am not error")
