# Hard Fork of gofmt

2022-08-31: Sync with go1.18.5
