/*MY TITLE!*/ // want `Expected:TITLE\., Actual: TITLE!`

//golangcitest:args -Egoheader
//golangcitest:config_path testdata/configs/go-header.yml
package testdata
