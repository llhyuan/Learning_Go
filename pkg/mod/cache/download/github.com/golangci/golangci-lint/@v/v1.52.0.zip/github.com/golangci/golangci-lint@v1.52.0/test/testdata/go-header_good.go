/*MY TITLE.*/

//golangcitest:args -Egoheader
//golangcitest:config_path testdata/configs/go-header.yml
//golangcitest:expected_exitcode 0
package testdata
