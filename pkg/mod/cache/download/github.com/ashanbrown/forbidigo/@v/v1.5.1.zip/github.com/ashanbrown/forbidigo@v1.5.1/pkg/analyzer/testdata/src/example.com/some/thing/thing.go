package thing

var Shiny int
var AlsoShiny int
