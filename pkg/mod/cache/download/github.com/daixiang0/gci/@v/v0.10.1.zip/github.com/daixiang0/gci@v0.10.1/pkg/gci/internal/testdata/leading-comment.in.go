package main

import (
	// foo
	"fmt"
)
