package main

import (
	"fmt"

	"github.com/forbidden/pkg" //nolint:depguard

	_ "github.com/daixiang0/gci" //nolint:depguard
)
