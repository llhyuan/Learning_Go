package main

import (
	"fmt"

	g "github.com/golang"

	"daixiang0/lib1"
	"github.com/daixiang0/gci"
	"github.com/daixiang0/gci/subtest"
	"gitlab.com/daixiang0/gci"
)
