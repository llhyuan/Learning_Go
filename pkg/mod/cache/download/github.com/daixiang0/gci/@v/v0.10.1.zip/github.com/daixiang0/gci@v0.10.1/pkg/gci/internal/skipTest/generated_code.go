package testdata

// DO NOT EDIT

import (
	"testing"

	"fmt"
)

// nolint
func Test(t *testing.T) {
	fmt.Println("test")
}
