package main

import (
	"fmt"

	g "github.com/golang"

	"github.com/daixiang0/a"
	"github.com/daixiang0/gci"
	"github.com/daixiang0/gci/subtest"

	_ "github.com/daixiang0/gci/blank"
	_ "github.com/golang/blank"

	. "github.com/daixiang0/gci/dot"
	. "github.com/golang/dot"
)
