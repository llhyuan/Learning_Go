package main

import "github.com/mgechev/revive/cli"

func main() {
	cli.RunRevive()
}
