// Test of block package comment.
// OK

/*
Package foo is pretty sweet.
*/
package foo
