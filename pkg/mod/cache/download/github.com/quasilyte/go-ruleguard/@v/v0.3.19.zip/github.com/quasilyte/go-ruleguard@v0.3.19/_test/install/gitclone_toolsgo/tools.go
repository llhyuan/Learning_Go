// +build tools

package tools

import (
	_ "github.com/quasilyte/go-ruleguard/dsl"
)
