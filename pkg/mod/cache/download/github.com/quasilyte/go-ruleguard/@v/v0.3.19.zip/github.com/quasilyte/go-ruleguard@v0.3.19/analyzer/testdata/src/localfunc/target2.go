package localfunc

func _() {
	test("fmt is imported")

	test("ioutil is imported")
}
