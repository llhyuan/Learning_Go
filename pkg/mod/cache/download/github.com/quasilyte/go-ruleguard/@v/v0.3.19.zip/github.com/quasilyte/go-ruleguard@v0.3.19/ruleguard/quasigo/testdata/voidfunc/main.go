package main

func main() {
	println("hello")
	println(1)
	x := "var"
	println(x)
}
