package foolib

type Stringer interface {
	String() string
}
