package checkers

import "go/types"

type contextStub struct {
	TypesInfo *types.Info
}
