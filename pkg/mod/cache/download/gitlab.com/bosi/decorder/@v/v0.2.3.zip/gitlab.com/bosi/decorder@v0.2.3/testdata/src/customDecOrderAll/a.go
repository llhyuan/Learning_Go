package customDecOrderAll

func a() {}

const b = 1

var c = 1

type d int
