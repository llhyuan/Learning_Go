package disabledDecNumCheck

type aa int
type ab int

const ac = 1
const ad = 1

var ae = 1
var af = 1
