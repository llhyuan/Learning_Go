package definition

type W int
